/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
      {
        protocol: "https",
        hostname: "i.pravatar.cc",
      },
    ],
  },
  webpack: (config) => {
    // This is only needed for development mode
    // In production mode, Next.js automatically loads SVGs as images
    if (process.env.NODE_ENV === "development") {
      // Find the rule that handles SVG files
      const fileLoaderRule = config.module.rules.find((rule) =>
        rule.test?.test?.(".svg")
      );

      if (fileLoaderRule) {
        // Exclude SVG files from the default rule
        fileLoaderRule.exclude = /\.svg$/i;

        // Add a new rule specifically for SVG files
        config.module.rules.push({
          test: /\.svg$/i,
          type: "asset",
          resourceQuery: /url/, // *.svg?url
        });

        // Add rule to handle SVG files as React components
        config.module.rules.push({
          test: /\.svg$/i,
          resourceQuery: { not: [/url/] }, // exclude if *.svg?url
          use: ["@svgr/webpack"],
        });
      }
    }

    return config;
  },
};

module.exports = nextConfig;
