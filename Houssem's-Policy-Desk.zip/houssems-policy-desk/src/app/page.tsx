import { MainNavigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import ResumeSection from "@/components/resume-section";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <MainNavigation />
      <main className="flex-1">
        <ResumeSection />
      </main>
      <Footer />
    </div>
  );
}
