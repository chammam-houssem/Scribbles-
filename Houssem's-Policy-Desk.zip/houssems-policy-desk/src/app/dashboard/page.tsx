import { MainNavigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import DataDashboard from "@/components/data-dashboard";

export const metadata = {
  title: "Data Dashboard | Houssem's Policy Desk",
  description: "Interactive data visualization for policy analysis",
};

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <MainNavigation />
      <main className="flex-1">
        <DataDashboard />
      </main>
      <Footer />
    </div>
  );
}
