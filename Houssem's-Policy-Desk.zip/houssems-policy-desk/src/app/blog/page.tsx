import { MainNavigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import BlogGallery from "@/components/blog-gallery";

export const metadata = {
  title: "Blog | Houssem's Policy Desk",
  description: "Policy analysis and research insights by Houssem",
};

export default function BlogPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <MainNavigation />
      <main className="flex-1">
        <BlogGallery />
      </main>
      <Footer />
    </div>
  );
}
