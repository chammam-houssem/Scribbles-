"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

// Mock data for Tunisia's budget
const budgetData = {
  yearlyData: [
    { year: 2018, revenue: 32.901, expenditure: 37.745, deficit: 4.844 },
    { year: 2019, revenue: 35.111, expenditure: 39.891, deficit: 4.780 },
    { year: 2020, revenue: 31.723, expenditure: 43.775, deficit: 12.052 },
    { year: 2021, revenue: 35.990, expenditure: 45.120, deficit: 9.130 },
    { year: 2022, revenue: 38.621, expenditure: 47.311, deficit: 8.690 },
    { year: 2023, revenue: 42.357, expenditure: 49.105, deficit: 6.748 }
  ],
  sectoralBreakdown: [
    { sector: "Education", percentage: 16.5, amount: 8.102 },
    { sector: "Health", percentage: 6.8, amount: 3.339 },
    { sector: "Defense", percentage: 5.3, amount: 2.602 },
    { sector: "Social Protection", percentage: 22.1, amount: 10.852 },
    { sector: "Infrastructure", percentage: 8.4, amount: 4.125 },
    { sector: "Debt Service", percentage: 23.2, amount: 11.392 },
    { sector: "Public Administration", percentage: 12.8, amount: 6.285 },
    { sector: "Agriculture", percentage: 2.9, amount: 1.424 },
    { sector: "Other", percentage: 2.0, amount: 0.982 }
  ],
  revenueBreakdown: [
    { source: "Tax Revenue", percentage: 87.3, amount: 36.978 },
    { source: "Non-Tax Revenue", percentage: 9.2, amount: 3.897 },
    { source: "Grants", percentage: 3.5, amount: 1.482 }
  ]
};

// Mock data for debt sustainability
const debtData = {
  debtToGDP: [
    { year: 2018, domestic: 25.3, external: 46.1, total: 71.4 },
    { year: 2019, domestic: 26.8, external: 50.9, total: 77.7 },
    { year: 2020, domestic: 29.1, external: 57.2, total: 86.3 },
    { year: 2021, domestic: 31.5, external: 58.7, total: 90.2 },
    { year: 2022, domestic: 32.8, external: 55.9, total: 88.7 },
    { year: 2023, domestic: 33.4, external: 52.1, total: 85.5 }
  ],
  debtService: [
    { year: 2018, principal: 4.89, interest: 2.13, total: 7.02, percentRevenue: 21.3 },
    { year: 2019, principal: 5.24, interest: 2.35, total: 7.59, percentRevenue: 21.6 },
    { year: 2020, principal: 6.76, interest: 2.85, total: 9.61, percentRevenue: 30.3 },
    { year: 2021, principal: 7.12, interest: 3.21, total: 10.33, percentRevenue: 28.7 },
    { year: 2022, principal: 7.53, interest: 3.86, total: 11.39, percentRevenue: 29.5 },
    { year: 2023, principal: 7.18, interest: 4.21, total: 11.39, percentRevenue: 26.9 }
  ],
  creditors: [
    { creditor: "Multilateral Institutions", percentage: 42.1, amount: 21.94 },
    { creditor: "Bilateral - Paris Club", percentage: 17.3, amount: 9.01 },
    { creditor: "Bilateral - Non-Paris Club", percentage: 13.6, amount: 7.09 },
    { creditor: "Commercial Banks", percentage: 6.2, amount: 3.23 },
    { creditor: "Bondholders", percentage: 20.8, amount: 10.84 }
  ]
};

// Mock data for renewable projects
const renewableData = {
  projects: [
    { name: "Sidi Salem Solar Park", type: "Solar PV", capacity: 120, investment: 134.5, status: "Operational", region: "North", completionYear: 2021 },
    { name: "Bizerte Wind Farm", type: "Wind", capacity: 180, investment: 198.2, status: "Operational", region: "North", completionYear: 2020 },
    { name: "Tataouine Solar Complex", type: "Solar PV", capacity: 100, investment: 109.7, status: "Construction", region: "South", completionYear: 2024 },
    { name: "Kairouan Solar Park", type: "Solar PV", capacity: 150, investment: 165.3, status: "Construction", region: "Central", completionYear: 2025 },
    { name: "Gabes Concentrated Solar", type: "CSP", capacity: 80, investment: 240.6, status: "Planning", region: "South", completionYear: 2026 },
    { name: "Nabeul Wind Extension", type: "Wind", capacity: 120, investment: 132.8, status: "Planning", region: "Northeast", completionYear: 2026 },
    { name: "Sfax Floating Solar", type: "Solar PV", capacity: 50, investment: 78.2, status: "Planning", region: "East", completionYear: 2027 },
    { name: "Gafsa Solar Park", type: "Solar PV", capacity: 200, investment: 210.5, status: "Planning", region: "Central", completionYear: 2027 },
    { name: "Jendouba Hydro Storage", type: "Hydro", capacity: 30, investment: 85.7, status: "Feasibility", region: "Northwest", completionYear: 2028 },
  ],
  capacityGrowth: [
    { year: 2018, wind: 245, solar: 65, hydro: 62, total: 372 },
    { year: 2019, wind: 245, solar: 85, hydro: 62, total: 392 },
    { year: 2020, wind: 425, solar: 95, hydro: 62, total: 582 },
    { year: 2021, wind: 425, solar: 215, hydro: 62, total: 702 },
    { year: 2022, wind: 425, solar: 295, hydro: 62, total: 782 },
    { year: 2023, wind: 425, solar: 375, hydro: 62, total: 862 },
    { year: 2024, wind: 425, solar: 475, hydro: 62, total: 962 },
    { year: 2025, wind: 425, solar: 625, hydro: 62, total: 1112 },
    { year: 2026, wind: 545, solar: 705, hydro: 62, total: 1312 },
    { year: 2027, wind: 545, solar: 955, hydro: 62, total: 1562 },
    { year: 2028, wind: 545, solar: 955, hydro: 92, total: 1592 }
  ],
  investmentByType: [
    { type: "Solar PV", value: 698.2, percentage: 51.1 },
    { type: "Wind", value: 331.0, percentage: 24.2 },
    { type: "CSP", value: 240.6, percentage: 17.6 },
    { type: "Hydro", value: 85.7, percentage: 6.3 },
    { type: "Other", value: 10.8, percentage: 0.8 }
  ]
};

export default function DataDashboard() {
  const [yearFilter, setYearFilter] = useState<string>("2023");
  const [regionFilter, setRegionFilter] = useState<string>("All");
  const [statusFilter, setStatusFilter] = useState<string>("All");

  // Filter projects based on selected filters
  const filteredProjects = renewableData.projects.filter(project => {
    const matchesRegion = regionFilter === "All" || project.region === regionFilter;
    const matchesStatus = statusFilter === "All" || project.status === statusFilter;
    return matchesRegion && matchesStatus;
  });

  // Get unique regions and statuses for filters
  const regions = ["All", ...new Set(renewableData.projects.map(project => project.region))];
  const statuses = ["All", ...new Set(renewableData.projects.map(project => project.status))];

  return (
    <section className="container py-12 md:py-16">
      <div className="mb-8 space-y-4">
        <h1 className="text-4xl font-bold">Data Dashboard</h1>
        <p className="text-xl text-muted-foreground">
          Interactive visualizations of key policy and economic indicators
        </p>
      </div>

      <Tabs defaultValue="budget" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="budget">Tunisia's Budget</TabsTrigger>
          <TabsTrigger value="debt">Debt Sustainability</TabsTrigger>
          <TabsTrigger value="renewable">Renewable Projects</TabsTrigger>
        </TabsList>

        {/* Tunisia's Budget Tab */}
        <TabsContent value="budget">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Budget Overview (2018-2023)</CardTitle>
                <CardDescription>Revenue, expenditure, and deficit trends over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={budgetData.yearlyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value.toFixed(2)} billion TND`} />
                      <Legend />
                      <Line type="monotone" dataKey="revenue" stroke="#4338ca" name="Revenue" />
                      <Line type="monotone" dataKey="expenditure" stroke="#e11d48" name="Expenditure" />
                      <Line type="monotone" dataKey="deficit" stroke="#fbbf24" name="Deficit" strokeDasharray="5 5" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>2023 Expenditure Breakdown</CardTitle>
                <CardDescription>Percentage allocation by sector</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={budgetData.sectoralBreakdown}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="sector" angle={-45} textAnchor="end" height={70} />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Bar dataKey="percentage" fill="#6366f1" name="% of Budget" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Detailed Budget Data (2023)</CardTitle>
              <CardDescription>Sectoral allocation of expenditure</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sector</TableHead>
                    <TableHead>Amount (billion TND)</TableHead>
                    <TableHead>Percentage</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {budgetData.sectoralBreakdown.map((item) => (
                    <TableRow key={item.sector}>
                      <TableCell>{item.sector}</TableCell>
                      <TableCell>{item.amount.toFixed(2)}</TableCell>
                      <TableCell>{item.percentage.toFixed(1)}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Debt Sustainability Tab */}
        <TabsContent value="debt">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Debt-to-GDP Ratio (2018-2023)</CardTitle>
                <CardDescription>Domestic, external, and total debt trajectory</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={debtData.debtToGDP}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value}% of GDP`} />
                      <Legend />
                      <Line type="monotone" dataKey="domestic" stroke="#0ea5e9" name="Domestic" />
                      <Line type="monotone" dataKey="external" stroke="#f43f5e" name="External" />
                      <Line type="monotone" dataKey="total" stroke="#8b5cf6" name="Total" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Debt Service (2018-2023)</CardTitle>
                <CardDescription>Principal and interest payments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={debtData.debtService}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value.toFixed(2)} billion TND`} />
                      <Legend />
                      <Bar dataKey="principal" stackId="a" fill="#14b8a6" name="Principal" />
                      <Bar dataKey="interest" stackId="a" fill="#f59e0b" name="Interest" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>External Debt by Creditor (2023)</CardTitle>
              <CardDescription>Breakdown of external debt by creditor type</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Creditor</TableHead>
                    <TableHead>Amount (billion TND)</TableHead>
                    <TableHead>Percentage</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {debtData.creditors.map((item) => (
                    <TableRow key={item.creditor}>
                      <TableCell>{item.creditor}</TableCell>
                      <TableCell>{item.amount.toFixed(2)}</TableCell>
                      <TableCell>{item.percentage.toFixed(1)}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Renewable Projects Tab */}
        <TabsContent value="renewable">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Renewable Capacity Growth</CardTitle>
                <CardDescription>Installed capacity by technology (MW)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={renewableData.capacityGrowth}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value} MW`} />
                      <Legend />
                      <Bar dataKey="wind" stackId="a" fill="#22c55e" name="Wind" />
                      <Bar dataKey="solar" stackId="a" fill="#f59e0b" name="Solar" />
                      <Bar dataKey="hydro" stackId="a" fill="#0ea5e9" name="Hydro" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Investment by Technology</CardTitle>
                <CardDescription>Allocation of investments across renewable types</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={renewableData.investmentByType} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="type" />
                      <Tooltip formatter={(value) => `${value.toFixed(1)} million USD`} />
                      <Legend />
                      <Bar dataKey="value" fill="#6366f1" name="Investment (million USD)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="space-y-1">
              <CardTitle>Renewable Energy Projects</CardTitle>
              <CardDescription>Filter and explore active and planned renewable energy projects</CardDescription>
              <div className="flex flex-wrap gap-4 pt-2">
                <div className="w-48">
                  <Select value={regionFilter} onValueChange={setRegionFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Region" />
                    </SelectTrigger>
                    <SelectContent>
                      {regions.map(region => (
                        <SelectItem key={region} value={region}>{region}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-48">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Status" />
                    </SelectTrigger>
                    <SelectContent>
                      {statuses.map(status => (
                        <SelectItem key={status} value={status}>{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Project Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Capacity (MW)</TableHead>
                    <TableHead>Investment (M USD)</TableHead>
                    <TableHead>Region</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Completion</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProjects.map((project) => (
                    <TableRow key={project.name}>
                      <TableCell>{project.name}</TableCell>
                      <TableCell>{project.type}</TableCell>
                      <TableCell>{project.capacity}</TableCell>
                      <TableCell>{project.investment.toFixed(1)}</TableCell>
                      <TableCell>{project.region}</TableCell>
                      <TableCell>{project.status}</TableCell>
                      <TableCell>{project.completionYear}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </section>
  );
}
