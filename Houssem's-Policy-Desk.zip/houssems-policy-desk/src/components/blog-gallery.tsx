"use client";

import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink } from "@/components/ui/pagination";
import { format } from "date-fns";

// Blog post data (mock data - replace with real data later)
const blogPosts = [
  {
    id: "1",
    title: "Tunisia's Economic Recovery: Challenges and Opportunities",
    excerpt: "An analysis of Tunisia's economic landscape and potential pathways for sustainable recovery in the post-pandemic era.",
    date: "2023-11-15",
    tags: ["Economics", "Tunisia", "Recovery", "Policy"],
    image: "https://images.unsplash.com/photo-1583058905141-deef2de746bb?q=80&w=1600&auto=format&fit=crop",
    content: `
      <h2>Tunisia's Economic Challenges</h2>
      <p>Tunisia faces significant economic challenges stemming from both internal and external factors. The COVID-19 pandemic has exacerbated pre-existing issues in the economy, leading to increased unemployment and budget deficits.</p>

      <h2>Key Opportunities</h2>
      <p>Despite these challenges, Tunisia possesses several strategic advantages that could drive economic recovery:</p>
      <ul>
        <li>Strategic location as a gateway between Europe and Africa</li>
        <li>Highly educated workforce with technical skills</li>
        <li>Growing digital and startup ecosystem</li>
        <li>Potential for renewable energy development</li>
      </ul>

      <h2>Policy Recommendations</h2>
      <p>Based on our analysis, we recommend the following policy measures to support sustainable economic recovery:</p>
      <ol>
        <li>Investment in digital infrastructure to support innovation</li>
        <li>Streamlining bureaucratic procedures to enhance business environment</li>
        <li>Targeted skill development programs aligned with market needs</li>
        <li>Fiscal reforms to address budget deficits while protecting social safety nets</li>
      </ol>

      <h2>Conclusion</h2>
      <p>Tunisia's path to economic recovery requires a balanced approach that addresses fiscal challenges while investing in future growth sectors. With appropriate policy interventions and international support, Tunisia can leverage its strengths to build a more resilient and inclusive economy.</p>
    `
  },
  {
    id: "2",
    title: "Renewable Energy Transition in North Africa",
    excerpt: "Examining the potential, challenges, and policy frameworks for accelerating renewable energy adoption in North African countries.",
    date: "2023-09-22",
    tags: ["Energy", "Renewables", "Climate", "Policy"],
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?q=80&w=1600&auto=format&fit=crop",
    content: `
      <h2>The Renewable Potential</h2>
      <p>North Africa possesses some of the world's highest potential for solar energy production, with average solar radiation levels among the highest globally. Wind energy potential is also significant, particularly in coastal regions.</p>

      <h2>Current Challenges</h2>
      <p>Despite this potential, several challenges have limited the growth of renewable energy in the region:</p>
      <ul>
        <li>Infrastructure limitations and grid connectivity issues</li>
        <li>Regulatory and policy uncertainties</li>
        <li>Limited financing mechanisms</li>
        <li>Technical capacity constraints</li>
      </ul>

      <h2>Policy Framework Recommendations</h2>
      <p>Developing effective policy frameworks is essential for accelerating the renewable energy transition. Key elements should include:</p>
      <ol>
        <li>Clear and stable regulatory frameworks with transparent permitting processes</li>
        <li>Effective incentive mechanisms, including feed-in tariffs or auction systems</li>
        <li>Policies to encourage private sector participation</li>
        <li>Regional cooperation for energy market integration</li>
      </ol>

      <h2>Case Studies: Success Stories</h2>
      <p>Morocco's Noor Solar Complex and Egypt's Benban Solar Park demonstrate how effective policy frameworks can attract investment and accelerate renewable energy deployment.</p>
    `
  },
  {
    id: "3",
    title: "Fiscal Policy and Debt Sustainability",
    excerpt: "A deep dive into fiscal policy challenges and strategies for maintaining debt sustainability in developing economies.",
    date: "2023-08-05",
    tags: ["Economics", "Fiscal Policy", "Debt", "Development"],
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1600&auto=format&fit=crop",
    content: `
      <h2>Understanding Debt Sustainability</h2>
      <p>Debt sustainability refers to a country's ability to meet its current and future debt obligations without requiring debt relief or accumulating arrears. For developing economies, this represents a significant challenge amid growing financing needs and limited fiscal space.</p>

      <h2>Current Challenges</h2>
      <p>Several factors have complicated debt management in developing economies:</p>
      <ul>
        <li>External shocks (pandemic, geopolitical conflicts)</li>
        <li>Rising interest rates globally</li>
        <li>Currency depreciation increasing foreign-denominated debt burdens</li>
        <li>Structural economic vulnerabilities</li>
      </ul>

      <h2>Effective Fiscal Policy Approaches</h2>
      <p>Managing debt sustainability requires holistic fiscal policy approaches:</p>
      <ol>
        <li>Strengthening domestic revenue mobilization through tax reforms</li>
        <li>Enhancing public expenditure efficiency</li>
        <li>Developing domestic debt markets to reduce foreign exchange risks</li>
        <li>Implementing counter-cyclical fiscal policies</li>
      </ol>

      <h2>International Coordination</h2>
      <p>International coordination mechanisms, including the G20 Common Framework, provide platforms for addressing debt challenges. However, improvements are needed to enhance effectiveness and timeliness of interventions.</p>
    `
  },
  {
    id: "4",
    title: "Youth Employment Strategies for Economic Growth",
    excerpt: "Analyzing effective policies for addressing youth unemployment and leveraging demographic dividends for economic development.",
    date: "2023-07-11",
    tags: ["Employment", "Youth", "Development", "Policy"],
    image: "https://images.unsplash.com/photo-1605918321071-d3e1883336a5?q=80&w=1600&auto=format&fit=crop",
    content: `
      <h2>The Youth Employment Challenge</h2>
      <p>Youth unemployment remains one of the most pressing economic and social challenges globally, with particularly high rates in developing regions. Beyond the economic cost, youth unemployment has significant social implications, including increased inequality and potential political instability.</p>

      <h2>Key Barriers to Youth Employment</h2>
      <p>Several structural factors contribute to high youth unemployment:</p>
      <ul>
        <li>Skills mismatch between education systems and labor market needs</li>
        <li>Limited job creation in formal sectors</li>
        <li>Insufficient entrepreneurship ecosystems</li>
        <li>Labor market rigidities</li>
      </ul>

      <h2>Effective Policy Interventions</h2>
      <p>Evidence suggests several policy approaches can effectively address youth employment challenges:</p>
      <ol>
        <li>Education-to-employment programs that bridge skills gaps</li>
        <li>Entrepreneurship support systems, including access to finance and mentorship</li>
        <li>Labor market reforms to reduce entry barriers</li>
        <li>Targeted subsidies and incentives for youth employment</li>
      </ol>

      <h2>Case Studies: Success Stories</h2>
      <p>Examples from Rwanda's technical and vocational education reforms and Tunisia's startup act demonstrate how targeted policies can create enabling environments for youth employment and entrepreneurship.</p>
    `
  },
  {
    id: "5",
    title: "Digital Transformation and Economic Development",
    excerpt: "Exploring how digital technologies can accelerate economic development and policy frameworks to ensure inclusive digital transformation.",
    date: "2023-06-18",
    tags: ["Digital", "Technology", "Development", "Innovation"],
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?q=80&w=1600&auto=format&fit=crop",
    content: `
      <h2>Digital Technologies as Development Accelerators</h2>
      <p>Digital technologies offer unprecedented opportunities to accelerate economic development through enhanced productivity, new business models, and improved service delivery. The digital economy is growing faster than the overall economy in many regions.</p>

      <h2>Digital Divides</h2>
      <p>Despite the potential, significant digital divides persist:</p>
      <ul>
        <li>Infrastructure gaps, including broadband connectivity</li>
        <li>Digital skills deficits</li>
        <li>Affordability challenges</li>
        <li>Regulatory barriers</li>
      </ul>

      <h2>Policy Framework for Inclusive Digital Transformation</h2>
      <p>Creating an enabling environment for inclusive digital transformation requires comprehensive policy approaches:</p>
      <ol>
        <li>Infrastructure investment, particularly in underserved areas</li>
        <li>Skills development programs for the digital economy</li>
        <li>Regulatory frameworks that encourage innovation while addressing risks</li>
        <li>Digital government services to improve public sector efficiency</li>
      </ol>

      <h2>Measuring Digital Development</h2>
      <p>Effective digital development policies require robust measurement frameworks. The Digital Economy and Society Index and ICT Development Index provide useful benchmarking tools to track progress and inform policy adjustments.</p>
    `
  },
  {
    id: "6",
    title: "Climate Finance for Developing Economies",
    excerpt: "Analyzing financing mechanisms and policy approaches to support climate adaptation and mitigation in developing economies.",
    date: "2023-05-25",
    tags: ["Climate", "Finance", "Development", "Policy"],
    image: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?q=80&w=1600&auto=format&fit=crop",
    content: `
      <h2>Climate Finance Landscape</h2>
      <p>Climate finance encompasses the financial resources dedicated to addressing climate change through mitigation and adaptation measures. Despite commitments from developed countries, significant gaps remain in meeting the financing needs of developing economies.</p>

      <h2>Key Challenges</h2>
      <p>Several challenges hinder effective climate finance mobilization and allocation:</p>
      <ul>
        <li>Insufficient scale of financing relative to needs</li>
        <li>Difficulties accessing available funding</li>
        <li>Imbalances between mitigation and adaptation financing</li>
        <li>Limited capacity to develop bankable projects</li>
      </ul>

      <h2>Innovative Financing Mechanisms</h2>
      <p>Several innovative approaches can enhance climate finance effectiveness:</p>
      <ol>
        <li>Blended finance structures to leverage private capital</li>
        <li>Green bonds and sustainability-linked bonds</li>
        <li>Climate risk insurance mechanisms</li>
        <li>Results-based financing approaches</li>
      </ol>

      <h2>Policy Recommendations</h2>
      <p>Enhancing climate finance effectiveness requires coordinated policy actions, including streamlining access procedures, building national capacity for climate finance readiness, and aligning financial flows with climate resilient development pathways.</p>
    `
  }
];

export default function BlogGallery() {
  const [selectedPost, setSelectedPost] = useState<typeof blogPosts[0] | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  // Collect all unique tags
  const allTags = Array.from(
    new Set(blogPosts.flatMap(post => post.tags))
  ).sort();

  // Filter posts based on selected tags
  const filteredPosts = selectedTags.length > 0
    ? blogPosts.filter(post =>
        selectedTags.some(tag => post.tags.includes(tag))
      )
    : blogPosts;

  // Pagination logic
  const postsPerPage = 4;
  const totalPages = Math.ceil(filteredPosts.length / postsPerPage);
  const currentPosts = filteredPosts.slice(
    (currentPage - 1) * postsPerPage,
    currentPage * postsPerPage
  );

  // Toggle tag selection
  const toggleTag = (tag: string) => {
    setSelectedTags(prev =>
      prev.includes(tag)
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
    setCurrentPage(1); // Reset to first page when tags change
  };

  return (
    <section className="container py-12 md:py-16">
      <div className="mb-8 space-y-4">
        <h1 className="text-4xl font-bold">Policy Blog</h1>
        <p className="text-xl text-muted-foreground">
          Analysis and insights on policy issues, economic development, and sustainable growth
        </p>
      </div>

      {/* Tags filter */}
      <div className="mb-8">
        <h2 className="text-lg font-medium mb-3">Filter by tags:</h2>
        <div className="flex flex-wrap gap-2">
          {allTags.map(tag => (
            <Badge
              key={tag}
              variant={selectedTags.includes(tag) ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => toggleTag(tag)}
            >
              {tag}
            </Badge>
          ))}
        </div>
      </div>

      {/* Blog post grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {currentPosts.map(post => (
          <Card
            key={post.id}
            className="overflow-hidden h-full flex flex-col cursor-pointer hover:shadow-md transition-all duration-200"
            onClick={() => setSelectedPost(post)}
          >
            <div className="aspect-video overflow-hidden">
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
              />
            </div>
            <CardHeader>
              <div className="space-y-1 mb-2">
                <CardTitle className="text-xl">{post.title}</CardTitle>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(post.date), 'MMMM d, yyyy')}
                </p>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="text-muted-foreground line-clamp-3">{post.excerpt}</p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2">
              {post.tags.map(tag => (
                <Badge key={tag} variant="secondary">{tag}</Badge>
              ))}
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <Pagination>
          <PaginationContent>
            {[...Array(totalPages)].map((_, i) => {
              const pageNumber = i + 1;
              return (
                <PaginationItem key={pageNumber}>
                  <PaginationLink
                    isActive={pageNumber === currentPage}
                    onClick={() => setCurrentPage(pageNumber)}
                  >
                    {pageNumber}
                  </PaginationLink>
                </PaginationItem>
              );
            })}
          </PaginationContent>
        </Pagination>
      )}

      {/* Blog post dialog */}
      <Dialog open={!!selectedPost} onOpenChange={(open) => !open && setSelectedPost(null)}>
        <DialogContent className="max-w-3xl">
          {selectedPost && (
            <>
              <DialogHeader>
                <div className="space-y-2">
                  <DialogTitle className="text-2xl">{selectedPost.title}</DialogTitle>
                  <p className="text-sm text-muted-foreground">
                    {format(new Date(selectedPost.date), 'MMMM d, yyyy')}
                  </p>
                  <div className="flex flex-wrap gap-2 pt-2">
                    {selectedPost.tags.map(tag => (
                      <Badge key={tag} variant="secondary">{tag}</Badge>
                    ))}
                  </div>
                </div>
              </DialogHeader>
              <div className="aspect-video overflow-hidden rounded-md mt-2 mb-4">
                <img
                  src={selectedPost.image}
                  alt={selectedPost.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div
                className="prose dark:prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: selectedPost.content }}
              />
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
