"use client";

import { useState, useRef, useEffect } from "react";
import Image from "next/image";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Resume data (mock data - replace with real data later)
const resumeData = {
  profile: {
    name: "Houssem",
    title: "Public Policy Analyst",
    bio: "Public Policy Analyst and MPP candidate with a strong foundation in data-driven analysis, fiscal policy, and strategic stakeholder engagement. I specialize in designing evidence-based policies for sustainable development in resource-constrained settings. My work bridges rigorous research with real-world impact, from fiscal transparency tools in Tunisia to youth empowerment initiatives across the Mediterranean.",
    email: "houssem@example.com",
    linkedin: "linkedin.com/in/houssem",
    twitter: "@houssem_policy",
    avatarUrl: "https://i.pravatar.cc/300"
  },
  sections: [
    {
      id: "experience",
      title: "Experience",
      items: [
        {
          title: "Trainee – Program Officer",
          organization: "North African Policy Initiative (NAPI) – Tunis – Hybrid",
          period: "Dec 2024 – Present",
          description: [
            "Designed and launched a Mediterranean youth policy platform",
            "Drafted funding proposals and co-developed training/research materials",
            "Delivered training on policy analysis and stakeholder engagement"
          ]
        },
        {
          title: "Student Assistant – Research & Events",
          organization: "German Institute for Global and Area Studies (GIGA) – Hamburg",
          period: "Mar 2024 – Dec 2024",
          description: [
            "Managed international academic events and outreach",
            "Researched political communication and authoritarianism",
            "Built research databases and wrote policy summaries"
          ]
        },
        {
          title: "Public Policy & Public Finance Lead",
          organization: "Al Bawsala – Tunis",
          period: "Jun 2021 – Apr 2023",
          description: [
            "Led IMF/WB engagement on debt, energy, and subsidy reform",
            "Managed 5+ multi-donor policy advocacy projects",
            "Created fiscal transparency tools and economic models",
            "Authored 3 major reports on post-COVID fiscal policy",
            "Built CSO partnerships and delivered technical training"
          ]
        },
        {
          title: "Policy Research & Advocacy Intern",
          organization: "Institute for Policy Studies (IPS) – Washington, D.C.",
          period: "May 2020 – Aug 2020",
          description: [
            "Wrote blog posts on U.S. COVID-19 fiscal policy",
            "Supported Senate testimony with data analysis",
            "Ran 3 infographics-based social media campaigns"
          ]
        },
        {
          title: "Regional Co-Manager",
          organization: "Bernie Sanders Campaign – Minnesota",
          period: "Nov 2019 – Apr 2020",
          description: [
            "Directed local campaign strategy and policy messaging",
            "Advocated for Green New Deal; secured county wins",
            "Managed campaign budgeting and event coordination"
          ]
        }
      ]
    },
    {
      id: "education",
      title: "Education",
      items: [
        {
          title: "Master of Public Policy (MPP)",
          organization: "Willy Brandt School of Public Policy – DAAD Scholar – Erfurt, Germany",
          period: "2023–2025",
          description: [
            "Specialization: Development & Socio-Economic Policies",
            "Thesis: Water in the Energy Transition – Mediterranean Political Economy",
            "Capstone Project: Facing Finance e.V."
          ]
        },
        {
          title: "Bachelor of Arts in Political Science/IR",
          organization: "Carleton College – Northfield, MN",
          period: "2017–2021",
          description: [
            "Minor: Public Policy Analysis",
            "GPA: 3.64 – Distinction among Major & Capstone",
            "Study Abroad: Development Economics in India & Bangladesh"
          ]
        }
      ]
    },
    {
      id: "skills",
      title: "Skills & Tools",
      items: [
        {
          title: "Policy Skills",
          description: [
            "Public policy development, stakeholder engagement",
            "Fiscal analysis, economic modeling, advocacy strategy"
          ]
        },
        {
          title: "Technical Skills",
          description: [
            "Advanced Excel, R, Python, AI tools for data and writing"
          ]
        },
        {
          title: "Languages",
          description: [
            "Arabic (native), English (full), French (working)",
            "German & Spanish (conversational)"
          ]
        }
      ]
    },
    {
      id: "awards",
      title: "Awards",
      items: [
        {
          title: "Recognition",
          description: [
            "U.S. Presidential Volunteer Service Award",
            "iEARN-Tunisia Award"
          ]
        }
      ]
    }
  ]
};

export default function ResumeSection() {
  const [activeSection, setActiveSection] = useState("experience");
  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // Register section refs
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      {
        rootMargin: "-10% 0px -70% 0px",
        threshold: 0
      }
    );

    // Observe all section elements
    Object.values(sectionRefs.current).forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => {
      observer.disconnect();
    };
  }, []);

  // Function to scroll to a specific section
  const scrollToSection = (sectionId: string) => {
    sectionRefs.current[sectionId]?.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  };

  return (
    <section className="container py-12 md:py-16">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Left column: Profile and contact info */}
        <div className="md:col-span-4 md:sticky top-24 self-start">
          <div className="space-y-6">
            <Avatar className="w-32 h-32 border">
              <AvatarImage src={resumeData.profile.avatarUrl} alt={resumeData.profile.name} />
              <AvatarFallback>{resumeData.profile.name.charAt(0)}</AvatarFallback>
            </Avatar>

            <div>
              <h1 className="text-3xl font-bold">{resumeData.profile.name}</h1>
              <p className="text-xl text-muted-foreground">{resumeData.profile.title}</p>
            </div>

            <div>
              <p className="text-muted-foreground">{resumeData.profile.bio}</p>
            </div>

            <div className="space-y-2 pt-2">
              <h3 className="font-semibold">Contact</h3>
              <div className="text-sm space-y-1">
                <p>Email: {resumeData.profile.email}</p>
                <p>LinkedIn: {resumeData.profile.linkedin}</p>
                <p>Twitter: {resumeData.profile.twitter}</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 pt-4">
              {resumeData.sections.map((section) => (
                <Badge
                  key={section.id}
                  variant={activeSection === section.id ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => scrollToSection(section.id)}
                >
                  {section.title}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Right column: Resume sections */}
        <div className="md:col-span-8 space-y-16">
          {resumeData.sections.map((section) => (
            <div
              key={section.id}
              id={section.id}
              ref={(el) => (sectionRefs.current[section.id] = el)}
              className="scroll-mt-24"
            >
              <h2 className="text-2xl font-bold mb-6">{section.title}</h2>
              <div className="space-y-8">
                {section.items.map((item, index) => (
                  <Card key={index} className="overflow-hidden transition-all duration-200 hover:shadow-md">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-semibold">{item.title}</h3>
                        {item.period && <span className="text-sm text-muted-foreground">{item.period}</span>}
                      </div>
                      {item.organization && (
                        <p className="text-muted-foreground mb-2">{item.organization}</p>
                      )}
                      <ul className="list-disc list-inside space-y-1 text-sm mt-2">
                        {item.description.map((point, i) => (
                          <li key={i}>{point}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
